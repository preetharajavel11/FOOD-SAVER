<?php

$username = $_POST['uname'];
$pass = $_POST['psw'];

include "db_conx.php";


$sql = "SELECT * FROM `claimer_users` WHERE username = '$username' AND password ='$pass' ";

$result = mysqli_query($conn, $sql);
$rows = mysqli_num_rows($result);

if ($rows == 0) {
    echo "Incorrect password";
    echo "<br/> <a href='c_login.php'>Click here to Login</a>";
    exit;
}

$row = mysqli_fetch_assoc($result);
mysqli_close($conn);

session_start();
$_SESSION['c_id'] = $row ['id'];

echo "Login success.";
echo "<br/> <a href='c_homepage.php'>Click here to proceed.</a>";