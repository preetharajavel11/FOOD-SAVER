<style>
body {
 background-color: #fefbd8;
}
h1 {
 background-color: #333;
color: white;
}
</style>
<div id="my_form">
 <center><h2>Welcome</h2></center>

<form action="c_signup_process.php" method="POST">
    <center>
    <img src="https://www.kindpng.com/picc/m/755-7554518_login-icon-cartoon-hd-png-download.png"height="150" width="250">
    <br>
    <br>

    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>
    <br>
    <br>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
    <br>
    <br>

    <label for="psw"><b>Re-enter-Password</b></label>
    <input type="password" placeholder="Re enter Password" name="rpsw" required>
    <br>
    <br>

    <button type="submit">Register</button>
    &nbsp;&nbsp;&nbsp;
	<a href="index.html">Back</a>
    </center>
</form>

</div>
