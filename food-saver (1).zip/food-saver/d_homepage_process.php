<?php

$college_name = $_POST['college_name'];
$coll_address = $_POST['coll_address'];
$food_quantity = $_POST['food_quantity'];
$food_type = $_POST['food_type'];
$phone = $_POST['phone'];
$email = $_POST['email'];

$added_at = date('Y-m-d H:i:s', strtotime("now"));
session_start();
$owner_id= $_SESSION['donar_id'];
$is_claimed = "NO";

include "db_conx.php";

$sql = "INSERT INTO `food_data` (college_name, college_address, food_quantity,food_type, contact_number, email, owner_id, is_claimed, added_at)
VALUES ('$college_name', '$coll_address', '$food_quantity', '$food_type', '$phone', '$email', '$owner_id', '$is_claimed', '$added_at')";

$result = mysqli_query($conn, $sql);

if ($result) {
    echo "Food Added successfully.";
    echo "<br/> <a href='d_homepage.php'>Click here to Go Back</a>";
} else {
    echo "Failed to add Food. ";
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);