<style>
body {
 background-color: #fefbd8;
}
h1 {
 background-color: #333;
color: white;
}
</style>
<div id="my_form">
 <center><h2>Welcome</h2></center>

<form action="c_login_process.php" method="POST">
<center>
	<img src="https://previews.123rf.com/images/limbi007/limbi0071301/limbi007130100033/17259439-orange-cartoon-character-with-green-button-login-.jpg"height="150" width="250">
	<br>
	<br>
	<label for="uname"><b>Username</b></label>
		<input type="text" placeholder="Enter Username" name="uname" required>
	<br>
	<br>
		<label for="psw"><b>Password</b></label>
		<input type="password" placeholder="Enter Password" name="psw" required>
	<br>
	<br>
	<button type="submit">Login</button>
	&nbsp;&nbsp;&nbsp;
	<a href="index.html">Back</a>
	<center>
</form>
 
</div>
