<?php

// Create connection
$conn = mysqli_connect("localhost", "root", "", "food_saver");
// Check connection
if (!$conn){
  die("Connection failed: " . mysqli_connect_error());
}
