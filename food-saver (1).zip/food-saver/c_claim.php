<?php

$fd_id = $_GET['fd_id'];
session_start();
$claimer_id = $_SESSION['c_id'];

include "db_conx.php";

$sql = "UPDATE `food_data` SET is_claimed = 'YES', claimer_id= '$claimer_id' WHERE id='$fd_id' ";

$result = mysqli_query($conn, $sql);

if ($result) {
    echo "Food Claimed successfully.";
    echo "<br/> <a href='c_homepage.php'>Click here to back</a>";
} else {
    echo "Food Claim Failed. ";
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "<br/> <a href='c_homepage.php'>Click here to back</a>";
}

mysqli_close($conn);