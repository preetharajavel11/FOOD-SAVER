<style>
body {
 background-color: #fefbd8;
}
h1 {
 background-color: #333;
color: white;
}
</style>

<center>
<title>FOOD SAVER</title>
<h1>COLLEGE HOSTEL</h1>
<form action="d_homepage_process.php" method="POST">
	<p><label>College name</label>
	<input type="text" name="college_name">
	<br>
	<p><label>College Address</label>
	<input type="text" name="coll_address">
	<br>
 	<p><label>Food Quantity</label>
	<input type="text" name="food_quantity">

	<p><label>Food Type</label>
	<input type="radio" id="VEG" name="food_type" value="VEG">
	<label for="VEG">Veg</label>
	<input type="radio" id="NONVEG" name="food_type" value="NONVEG">
	<label for="NONVEG">Non-Veg</label><br>

  <p><label>Contact Number</label>
	<input type="text" name="phone">

	<p><label>Email Address</label>
	<input type="email" name="email" required>

	    <h5>*note:only for orphanage</h5>
	</div></p>
 	<button type="submit">Submit</button>

</form>
<br/>
<br/>
<br/>
<a href="index.html">Back to home</a>
</center>