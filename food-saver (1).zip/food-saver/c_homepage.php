<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>

<h1>Food Available for Claim</h1>

<table id="customers">
  <tr>
    <th>S.no.</th>
    <th>College name</th>
    <th>Food Quantity</th>
    <th>Food Type</th>
    <th>Claimed</th>
    <th>Options</th>
  </tr>

  <?php

    include "db_conx.php";

    $sql = "SELECT * FROM `food_data` WHERE is_claimed = 'NO' ";

    $result = mysqli_query($conn, $sql);
    $rows = mysqli_num_rows($result);

    if ($rows == 0) {
        echo "<tr>  <td colspan='6'> No Food Available </td> </tr>";
    }else{
        $i =0;
        while( $row = mysqli_fetch_assoc($result)){
        $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $row['college_name']; ?></td>
            <td><?php echo $row['food_quantity']; ?></td>
            <td><?php echo $row['food_type']; ?></td>
            <td><?php echo $row['is_claimed']; ?></td>
            <td><a href="c_claim.php?fd_id=<?php echo $row['id']; ?>">Claim</a></td>
        </tr>
    <?php
        }
    }
    mysqli_close($conn);
  ?>

</table>

<br/>
<a href="index.html">Back to home</a>

</body>
</html>


