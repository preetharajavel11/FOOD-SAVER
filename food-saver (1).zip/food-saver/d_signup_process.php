<?php



$username = $_POST['uname'];
$pass = $_POST['psw'];
$rpass = $_POST['rpsw'];

if($pass != $rpass){
    echo ("Password and Re-Enter Password doesnt match.");
    echo "<br/> <a href='d_signup.php'> Go Back</a>";
    exit;
}

include "db_conx.php";


$sql = "INSERT INTO `donor_users` (username, password)
VALUES ('$username', '$pass')";

$result = mysqli_query($conn, $sql);

if ($result) {
    echo "Registered successfully.";
    echo "<br/> <a href='d_login.php'>Click here to Login</a>";
} else {
    echo "Registered Failed. ";
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);